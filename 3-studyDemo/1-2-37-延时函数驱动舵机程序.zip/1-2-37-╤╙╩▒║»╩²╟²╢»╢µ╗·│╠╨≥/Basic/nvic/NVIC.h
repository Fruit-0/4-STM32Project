#ifndef __NVIC_H
#define __NVIC_H	 
#include "sys.h"


extern u8 INT_MARK;//�жϱ�־λ


void KEYPAD4x4_INT_INIT (void);

#endif
